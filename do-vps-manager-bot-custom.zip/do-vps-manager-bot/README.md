# DigitalOcean VPS Manager Bot

Telegram bot berbasis **Python + Pyrogram** untuk membuat dan mengelola DigitalOcean Droplets melalui DigitalOcean API.

## Fitur

- Melihat region dan ukuran Droplet yang tersedia.
- Membuat Droplet Ubuntu 24.04 dengan konfirmasi inline.
- Cloud-init memasang Docker, Git, dan curl.
- Melihat daftar Droplet yang dikelola bot.
- Memeriksa status dan IP publik.
- Menghapus Droplet dengan konfirmasi.
- Hanya Telegram user ID dalam `OWNER_IDS` yang dapat memakai bot.
- Bot hanya menghapus Droplet yang memiliki tag `managed-by-telegram-bot`.
- Batas jumlah Droplet yang dikelola bot dapat diatur.

## Persyaratan

- Python 3.10 atau lebih baru.
- Telegram bot token dari BotFather.
- Telegram API ID dan API Hash dari https://my.telegram.org.
- DigitalOcean Personal Access Token dengan izin yang diperlukan untuk membaca, membuat, dan menghapus Droplet.
- SSH public key yang sudah ditambahkan ke akun DigitalOcean.

> **Peringatan biaya:** membuat Droplet dapat menimbulkan biaya. Periksa harga pada akun DigitalOcean sebelum mengonfirmasi. Menghapus Droplet dapat menghilangkan data di dalamnya. Bot ini tidak dapat menetapkan batas tagihan akun DigitalOcean.

## Instalasi di Ubuntu VPS

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip git

git clone https://github.com/USERNAME/do-vps-manager-bot.git
cd do-vps-manager-bot

python3 -m venv .venv
source .venv/bin/activate

pip install --upgrade pip
pip install -r requirements.txt

cp .env.example .env
nano .env
```

Isi semua variabel di `.env`. Jangan unggah file `.env` ke GitHub.

Jalankan:

```bash
source .venv/bin/activate
python bot.py
```

## Perintah Telegram

| Perintah | Fungsi |
|---|---|
| `/start` | Mulai bot |
| `/help` | Bantuan |
| `/regions` | Daftar region |
| `/sizes` | Daftar ukuran VPS dan harga bulanan |
| `/images` | Image OS default |
| `/create nama region size` | Minta pembuatan VPS |
| `/droplets` | Daftar VPS yang dikelola bot |
| `/status ID` | Detail VPS |
| `/delete ID` | Minta penghapusan VPS |

Contoh:

```text
/create server-demo sgp1 s-1vcpu-1gb
```

Bot akan menampilkan ringkasan konfigurasi dan meminta konfirmasi sebelum membuat Droplet.

## Menjalankan dengan systemd

Buat service:

```bash
sudo nano /etc/systemd/system/do-vps-manager.service
```

Isi (sesuaikan path folder dan username Linux):

```ini
[Unit]
Description=DigitalOcean VPS Manager Telegram Bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=/opt/do-vps-manager-bot
ExecStart=/opt/do-vps-manager-bot/.venv/bin/python /opt/do-vps-manager-bot/bot.py
Restart=on-failure
RestartSec=5
EnvironmentFile=/opt/do-vps-manager-bot/.env

[Install]
WantedBy=multi-user.target
```

Aktifkan:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now do-vps-manager
sudo systemctl status do-vps-manager
```

Lihat log:

```bash
sudo journalctl -u do-vps-manager -f
```

## Catatan keamanan

- Jangan membagikan `.env`, token Telegram, atau DigitalOcean token.
- Gunakan SSH key, bukan password root.
- Batasi akses token DigitalOcean pada izin minimum yang diperlukan.
- Periksa tag dan nama Droplet sebelum menghapus.
- `MAX_MANAGED_DROPLETS` default `1`; ubah hanya setelah memahami biaya dan kebutuhan.
- Daftar Droplet diambil dari halaman pertama API (`per_page=200`).
